# multiprecision

Use `boost::multiprecision` as `integer_type` and `floating_type`.

## build

Install [boost](https://boost.org).

Then, build toml11 with `-DTOML11_BUILD_EXAMPLES=ON`

```cpp
$ cmake -B ./build/ -DTOML11_BUILD_EXAMPLES=ON
```
