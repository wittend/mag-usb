#ifndef TOML11_REGION_HPP
#define TOML11_REGION_HPP

#include "fwd/region_fwd.hpp" // IWYU pragma: export

#if ! defined(TOML11_COMPILE_SOURCES)
#include "impl/region_impl.hpp" // IWYU pragma: export
#endif

#endif // TOML11_REGION_HPP
