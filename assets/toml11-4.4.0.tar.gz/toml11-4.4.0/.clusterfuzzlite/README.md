# ClusterFuzzLite set up

This folder contains a fuzzing set for [ClusterFuzzLite](https://google.github.io/clusterfuzzlite).
