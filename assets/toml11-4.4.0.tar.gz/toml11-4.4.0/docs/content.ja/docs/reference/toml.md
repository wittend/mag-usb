+++
title = "toml.hpp"
type  = "docs"
+++

# toml.hpp

`toml.hpp`は、他の全てのヘッダを `include` します。

これによって、toml11の全機能が使用可能になります。

このヘッダファイルと `toml_fwd.hpp` は `${TOML11_INCLUDE_DIR}/` 以下に、
他のヘッダファイルは `${toml11_include_dir}/toml11/` 以下にあります。

